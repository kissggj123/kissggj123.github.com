﻿using CCWin;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Management;
using System.Collections;
using System.IO;
using System.Net.NetworkInformation;

namespace Yumiko_Manager_App
{


    public partial class Form1 : CCSkinMain
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "";
            label2.Text = "";
            richTextBox1.GotFocus += richTextBox1_GotFocus;
            richTextBox1.MouseDown += richTextBox1_MouseDown;
            this.Opacity = (double)(tmdbar.Value) / 100;
            tmdper.Text = this.Opacity * 100 + "%";
            //tmdbar.Value = (int)this.Opacity;

        }


        [DllImport("user32", EntryPoint = "HideCaret")]
        private static extern bool HideCaret(IntPtr hWnd);
        void richTextBox1_GotFocus(object sender, EventArgs e)
        {
            //HideCaret((sender as richTextBox1).Handle);
        }

        void richTextBox1_MouseDown(object sender, MouseEventArgs e)
        {
            //HideCaret((sender as richTextBox1).Handle);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string file = "result.txt";
            //string results = richTextBox1.Text.ToString();
            string temp = null, tempType = null;
            object displayName = null, uninstallString = null, releaseType = null;
            RegistryKey currentKey = null;
            int softNum = 0;
            RegistryKey pregkey = Registry.LocalMachine.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall");//获取指定路径下的键
            try
            {
                foreach (string item in pregkey.GetSubKeyNames())               //循环所有子键
                {
                    currentKey = pregkey.OpenSubKey(item);
                    displayName = currentKey.GetValue("DisplayName");           //获取显示名称
                    uninstallString = currentKey.GetValue("UninstallString");   //获取卸载字符串路径
                    releaseType = currentKey.GetValue("ReleaseType");           //发行类型,值是Security Update为安全更新,Update为更新
                    bool isSecurityUpdate = false;
                    if (releaseType != null)
                    {
                        tempType = releaseType.ToString();
                        if (tempType == "Security Update" || tempType == "Update")
                            isSecurityUpdate = true;
                    }
                    if (!isSecurityUpdate && displayName != null && uninstallString != null)
                    {
                        softNum++;
                        temp += displayName.ToString() + Environment.NewLine;
                    }
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message.ToString());
            }
            richTextBox1.Text = "已获取到的软件列表" + Environment.NewLine + temp;
            label1.Text = "你本机安装了" + softNum.ToString() + "个程序,已导出为result.txt";
            pregkey.Close();
            if (System.IO.File.Exists(Environment.CurrentDirectory + "\\" + file))
            {
                File.Delete(Environment.CurrentDirectory + "\\" + file);
                FileStream resultStream = new FileStream(Environment.CurrentDirectory + "\\" + file, FileMode.Append);
                StreamWriter streamWriter = new StreamWriter(resultStream, Encoding.Default);
                streamWriter.Write("已获取到的软件列表" + Environment.NewLine + temp);
                streamWriter.Flush();
                streamWriter.Close();
                resultStream.Close();
            }
            else
            {
                FileStream resultStream = new FileStream(Environment.CurrentDirectory + "\\" + file, FileMode.Append);
                StreamWriter streamWriter = new StreamWriter(resultStream, Encoding.Default);
                streamWriter.Write("已获取到的软件列表" + Environment.NewLine + temp);
                streamWriter.Flush();
                streamWriter.Close();
                resultStream.Close();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryKey RegistryKey = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows NT\\CurrentVersion");
            string pathName = (string)RegistryKey.GetValue("productName");
            //Version currentVersion = Environment.OSVersion.Version;
            //RegistryKey RegistryKey2 = Registry.LocalMachine.OpenSubKey("Software\\Microsoft\\Windows NT\\CurrentVersion");
            //string servicePack = RegistryKey2.GetValue("CSDVersion").ToString();
            label2.Text = "当前版本为" + pathName + " " + Environment.OSVersion.Version;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string ipStr = "iplc-jp1.cloudiplc.com";
            //构造Ping实例
            Ping pingSender = new Ping();
            //Ping 选项设置
            PingOptions options = new PingOptions();
            options.DontFragment = true;
            //测试数据
            string data = "";
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            //设置超时时间
            int timeout = 120;
            //调用同步 send 方法发送数据,将返回结果保存至PingReply实例
            PingReply reply = pingSender.Send(ipStr, timeout, buffer, options);
            if (reply.Status == IPStatus.Success)
            {
                Console.WriteLine("答复的主机地址：" + reply.Address.ToString());
                Console.WriteLine("往返时间：" + reply.RoundtripTime);
                Console.WriteLine("生存时间（TTL）：" + reply.Options.Ttl);
                Console.WriteLine("是否控制数据包的分段：" + reply.Options.DontFragment);
                Console.WriteLine("缓冲区大小：" + reply.Buffer.Length);
                MessageBox.Show("开发@泡芙老司机\r\n仅供测试用\r\n当前服务器延迟为" + reply.RoundtripTime + "ms", "关于 Yumiko Manager App", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Console.WriteLine(reply.Status.ToString());
                MessageBox.Show("开发@泡芙老司机\r\n仅供测试用\r\n当前服务器检测失败", "关于 Yumiko Manager App", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void tmdbar_ValueChanged(object sender, EventArgs e)
        {
            int tmdbarnum = tmdbar.Value;
            tmdper.Text = tmdbar.Value.ToString() + "%";
            //this.SkinOpacity = tmdbarnum / 100;
        }

        private void tmdbar_Scroll(object sender, EventArgs e)
        {
            Form1 YMA = this;
            YMA.Opacity = (double)(tmdbar.Value) / 100;
        }
    }
}
